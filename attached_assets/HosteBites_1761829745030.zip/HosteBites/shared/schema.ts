import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const mealData = pgTable("meal_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  mealType: text("meal_type").notNull(),
  personName: text("person_name").notNull(),
  lastReset: timestamp("last_reset").notNull(),
});

export const insertMealDataSchema = createInsertSchema(mealData).omit({
  id: true,
});

export type InsertMealData = z.infer<typeof insertMealDataSchema>;
export type MealData = typeof mealData.$inferSelect;

export type MealType = 'Breakfast' | 'Lunch' | 'Dinner';

export interface MealStatus {
  eaten_count: number;
  eaten: string[];
  not_eaten_count: number;
}

export interface StatusResponse {
  Breakfast: MealStatus;
  Lunch: MealStatus;
  Dinner: MealStatus;
  last_reset: string;
  expected: number;
}

export interface VoteRequest {
  name: string;
  meal: MealType;
}

export interface VoteResponse {
  success: boolean;
  message: string;
}

export interface ResetRequest {
  meal: MealType;
}

export interface ResetResponse {
  success: boolean;
  message: string;
}

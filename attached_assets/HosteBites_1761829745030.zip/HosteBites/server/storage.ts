import type { MealType, MealStatus, StatusResponse } from "@shared/schema";
import { writeFileSync, readFileSync, existsSync } from "fs";
import { join } from "path";

const DATA_FILE = join(process.cwd(), 'data.json');
const PRESET_FILE = join(process.cwd(), 'names.json');

interface MealDataStructure {
  meals: {
    Breakfast: { eaten: string[] };
    Lunch: { eaten: string[] };
    Dinner: { eaten: string[] };
  };
  last_reset: string;
}

export interface IStorage {
  getStatus(expectedCount: number): Promise<StatusResponse>;
  vote(name: string, meal: MealType, expectedCount: number): Promise<{ success: boolean; message: string }>;
  getPresetNames(): Promise<string[]>;
  exportData(): Promise<Array<{ meal: string; name: string; date: string }>>;
  resetMeal(meal: MealType): Promise<{ success: boolean; message: string }>;
  resetAll(): Promise<{ success: boolean; message: string }>;
}

export class MemStorage implements IStorage {
  private data: MealDataStructure;

  constructor() {
    this.data = this.loadData();
  }

  private loadData(): MealDataStructure {
    if (!existsSync(DATA_FILE)) {
      const initialData: MealDataStructure = {
        meals: {
          Breakfast: { eaten: [] },
          Lunch: { eaten: [] },
          Dinner: { eaten: [] },
        },
        last_reset: new Date().toISOString(),
      };
      this.saveData(initialData);
      return initialData;
    }

    try {
      const content = readFileSync(DATA_FILE, 'utf-8');
      return JSON.parse(content);
    } catch (error) {
      return {
        meals: {
          Breakfast: { eaten: [] },
          Lunch: { eaten: [] },
          Dinner: { eaten: [] },
        },
        last_reset: new Date().toISOString(),
      };
    }
  }

  private saveData(data: MealDataStructure): void {
    try {
      writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
      this.data = data;
    } catch (error) {
      console.error('Failed to save data:', error);
    }
  }

  private ensureResetIfNeeded(): void {
    try {
      const lastReset = new Date(this.data.last_reset);
      const now = new Date();
      
      // Reset daily at midnight
      const lastResetDay = new Date(lastReset.getFullYear(), lastReset.getMonth(), lastReset.getDate());
      const nowDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      
      if (nowDay.getTime() > lastResetDay.getTime()) {
        this.data = {
          meals: {
            Breakfast: { eaten: [] },
            Lunch: { eaten: [] },
            Dinner: { eaten: [] },
          },
          last_reset: now.toISOString(),
        };
        this.saveData(this.data);
        console.log('Auto-reset performed: New day detected');
      }
    } catch (error) {
      console.error('Error checking reset:', error);
    }
  }

  private normalizeName(name: string): string {
    return name
      .trim()
      .split(/\s+/)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  }

  async getStatus(expectedCount: number): Promise<StatusResponse> {
    this.ensureResetIfNeeded();

    const response: StatusResponse = {
      Breakfast: this.getMealStatus('Breakfast', expectedCount),
      Lunch: this.getMealStatus('Lunch', expectedCount),
      Dinner: this.getMealStatus('Dinner', expectedCount),
      last_reset: this.data.last_reset,
      expected: expectedCount,
    };

    return response;
  }

  private getMealStatus(meal: MealType, expectedCount: number): MealStatus {
    const eaten = this.data.meals[meal].eaten;
    return {
      eaten_count: eaten.length,
      eaten: eaten,
      not_eaten_count: Math.max(0, expectedCount - eaten.length),
    };
  }

  async vote(name: string, meal: MealType, expectedCount: number): Promise<{ success: boolean; message: string }> {
    if (!name || !name.trim()) {
      return { success: false, message: 'Name is required.' };
    }

    if (!['Breakfast', 'Lunch', 'Dinner'].includes(meal)) {
      return { success: false, message: 'Valid meal required.' };
    }

    this.ensureResetIfNeeded();

    const normalizedName = this.normalizeName(name);
    const eaten = this.data.meals[meal].eaten;

    if (eaten.includes(normalizedName)) {
      return { success: false, message: 'You already voted for this meal.' };
    }

    eaten.push(normalizedName);
    this.saveData(this.data);

    return { success: true, message: 'Vote recorded.' };
  }

  async resetMeal(meal: MealType): Promise<{ success: boolean; message: string }> {
    if (!['Breakfast', 'Lunch', 'Dinner'].includes(meal)) {
      return { success: false, message: 'Invalid meal type.' };
    }

    this.data.meals[meal].eaten = [];
    this.saveData(this.data);

    return { success: true, message: `${meal} votes reset successfully.` };
  }

  async resetAll(): Promise<{ success: boolean; message: string }> {
    this.data = {
      meals: {
        Breakfast: { eaten: [] },
        Lunch: { eaten: [] },
        Dinner: { eaten: [] },
      },
      last_reset: new Date().toISOString(),
    };
    this.saveData(this.data);

    return { success: true, message: 'All votes reset successfully.' };
  }

  async getPresetNames(): Promise<string[]> {
    if (!existsSync(PRESET_FILE)) {
      return [];
    }

    try {
      const content = readFileSync(PRESET_FILE, 'utf-8');
      return JSON.parse(content);
    } catch (error) {
      return [];
    }
  }

  async exportData(): Promise<Array<{ meal: string; name: string; date: string }>> {
    this.ensureResetIfNeeded();

    const dateStr = new Date().toISOString().replace('T', ' ').split('.')[0];
    const rows: Array<{ meal: string; name: string; date: string }> = [];

    (['Breakfast', 'Lunch', 'Dinner'] as const).forEach((meal) => {
      this.data.meals[meal].eaten.forEach((name) => {
        rows.push({ meal, name, date: dateStr });
      });
    });

    return rows;
  }
}

export const storage = new MemStorage();

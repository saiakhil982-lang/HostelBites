import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import type { VoteRequest, MealType } from "@shared/schema";
import { readFileSync, existsSync } from "fs";
import { join } from "path";

const EXPECTED_COUNT = parseInt(process.env.EXPECTED_COUNT || '70', 10);

export async function registerRoutes(app: Express): Promise<Server> {
  app.get('/api/status', async (req, res) => {
    try {
      const status = await storage.getStatus(EXPECTED_COUNT);
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch status' });
    }
  });

  app.post('/api/vote', async (req, res) => {
    try {
      const { name, meal } = req.body as VoteRequest;
      const result = await storage.vote(name, meal, EXPECTED_COUNT);
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  });

  app.post('/api/reset/:meal', async (req, res) => {
    try {
      const meal = req.params.meal as MealType;
      const result = await storage.resetMeal(meal);
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  });

  app.post('/api/reset-all', async (req, res) => {
    try {
      const result = await storage.resetAll();
      res.json(result);
    } catch (error) {
      res.status(500).json({ success: false, message: 'Internal server error' });
    }
  });

  app.get('/api/preset-names', async (req, res) => {
    try {
      const names = await storage.getPresetNames();
      res.json(names);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch preset names' });
    }
  });

  app.get('/api/export', async (req, res) => {
    try {
      const data = await storage.exportData();
      
      let csv = 'Meal,Name,Date\n';
      data.forEach(row => {
        csv += `${row.meal},${row.name},${row.date}\n`;
      });

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=hostelbites_export.csv');
      res.send(csv);
    } catch (error) {
      res.status(500).json({ error: 'Failed to export data' });
    }
  });

  app.get('/api/download-files', async (req, res) => {
    try {
      const namesPath = join(process.cwd(), 'names.json');
      const dataPath = join(process.cwd(), 'data.json');
      
      const files: any = {};
      
      if (existsSync(namesPath)) {
        files.names = JSON.parse(readFileSync(namesPath, 'utf-8'));
      }
      
      if (existsSync(dataPath)) {
        files.data = JSON.parse(readFileSync(dataPath, 'utf-8'));
      }

      res.json(files);
    } catch (error) {
      res.status(500).json({ error: 'Failed to download files' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

# HostelBites - Meal Tracker 🍽️

A beautiful meal tracking system for your hostel. Track who's eaten for Breakfast, Lunch, and Dinner with live counts and see who's yet to eat!

## ✨ Features

✅ **Search & Vote**: Search for your name and vote when you've eaten  
📊 **Two-Column View**: See both "Who Ate" and "Not Eaten Yet" side by side  
🔄 **Live Updates**: Real-time counts updated every 5 seconds  
🎉 **Confetti Celebration**: Fun animation when you vote!  
🔁 **Reset Buttons**: Reset individual meal sections when needed  
⏰ **Auto-Reset**: Data automatically resets daily at midnight  
📥 **CSV Export**: Download attendance records anytime  
💾 **Backup Files**: Download names.json and data.json to your computer  
🎨 **Beautiful Animations**: Floating and gradient animations for visual appeal  
🌐 **Multi-User**: Link works for everyone - all girls can vote simultaneously  

## 🔧 Managing Girls' Names

**Important**: The `names.json` file contains all the girls in your hostel. You can update this file anytime to add or remove names.

### To Update Names:

1. Click the "Backup Files" button in the app to download current data
2. Open the downloaded `hostelbites_backup.json` file
3. Extract the "names" array and save it as `names.json`:

```json
[
  "Girl Name 1",
  "Girl Name 2",
  "Girl Name 3",
  ...add up to 70 names
]
```

4. Place the updated `names.json` file in your project directory
5. Restart the application

The same 70 names will appear in all three meal sections (Breakfast, Lunch, Dinner).

## 🎯 How to Use

1. **Vote for a Meal**: Search your name → Select it → Click "I've eaten"
2. **See Who's Left**: Check the "Not Eaten Yet" column for each meal
3. **Reset if Needed**: Click the "Reset" button on any meal section to clear votes
4. **Download Data**: Export CSV for records or backup files for updating names

## ⚙️ Configuration

Set the expected number of girls (default is 70):

```bash
EXPECTED_COUNT=70
```

## 📁 File Structure

```
names.json          ← Edit this file to update girls' names
data.json           ← Auto-generated, stores votes (auto-resets daily)
README.md           ← This file
```

## 🚀 Running the App

The app runs on port 5000 by default. Everyone on the same network can access it using your computer's IP address:

```
http://YOUR_IP_ADDRESS:5000
```

All girls can vote simultaneously from their own devices!

## 🔄 Auto-Reset Feature

The system automatically resets all votes at midnight every day. This means:
- Yesterday's votes are cleared
- Fresh start for the new day
- No manual reset needed (unless you want to reset mid-day)

## 💡 Tips

- **Backup Regularly**: Use "Backup Files" to save your data locally
- **Update Names Easily**: Download backup → Edit names → Replace file → Restart
- **Multi-Device Access**: Share the link with all hostel girls
- **Reset Anytime**: Use individual reset buttons if meals get confusing

---

Made with 💖 for your hostel community

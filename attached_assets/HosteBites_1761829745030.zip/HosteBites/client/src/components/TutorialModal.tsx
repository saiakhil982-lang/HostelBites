import { Button } from "@/components/ui/button";

interface TutorialModalProps {
  onClose: () => void;
}

export default function TutorialModal({ onClose }: TutorialModalProps) {
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-6">
      <div className="bg-card rounded-2xl shadow-xl p-6 w-full max-w-md text-center">
        <div className="text-4xl mb-3">💖</div>
        <h2 className="text-xl font-bold text-primary mb-3">
          Welcome to HostelBites
        </h2>
        <p className="text-sm text-muted-foreground mb-6">
          Enter your name and tap a meal card when you've eaten. Everyone can see live counts — simple and fun!
        </p>
        <Button 
          onClick={onClose}
          className="w-full"
          data-testid="button-tutorial-close"
        >
          Got it!
        </Button>
      </div>
    </div>
  );
}

import type { StatusResponse } from "@shared/schema";

interface LiveSummaryProps {
  status: StatusResponse;
}

const mealProgressColors = {
  Breakfast: 'bg-pink-300 dark:bg-pink-600',
  Lunch: 'bg-purple-300 dark:bg-purple-600',
  Dinner: 'bg-emerald-300 dark:bg-emerald-600',
};

export default function LiveSummary({ status }: LiveSummaryProps) {
  const calculatePercent = (mealType: 'Breakfast' | 'Lunch' | 'Dinner') => {
    const eaten = status[mealType]?.eaten_count || 0;
    const total = status.expected || 70;
    return Math.min(100, Math.round((eaten / total) * 100));
  };

  return (
    <aside className="backdrop-blur-md bg-card/55 rounded-2xl p-6 shadow-lg border border-card-border">
      <h3 className="text-lg font-semibold text-primary mb-4">Live Summary</h3>
      <div className="space-y-6">
        {(['Breakfast', 'Lunch', 'Dinner'] as const).map((mealType) => (
          <div key={mealType} data-testid={`summary-${mealType.toLowerCase()}`}>
            <div className="text-sm text-muted-foreground mb-2">{mealType}</div>
            <div className="flex items-center justify-between mb-3">
              <div 
                className="text-2xl font-bold text-foreground tabular-nums"
                data-testid={`text-count-${mealType.toLowerCase()}`}
              >
                {status[mealType].eaten_count}
              </div>
              <div className="text-sm text-muted-foreground">
                Yet: <span className="tabular-nums">{status[mealType].not_eaten_count}</span>
              </div>
            </div>
            <div className="w-full bg-secondary rounded h-2 overflow-hidden">
              <div
                className={`h-2 rounded transition-all duration-400 ${mealProgressColors[mealType]}`}
                style={{ width: `${calculatePercent(mealType)}%` }}
              />
            </div>
          </div>
        ))}
        <div className="mt-6 text-xs text-muted-foreground">
          Live updates every 5s
        </div>
      </div>
    </aside>
  );
}

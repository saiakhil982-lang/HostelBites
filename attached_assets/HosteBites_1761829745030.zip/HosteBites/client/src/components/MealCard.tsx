import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Search, Check, X, RotateCcw, Circle } from "lucide-react";
import type { MealType, MealStatus } from "@shared/schema";

interface MealCardProps {
  mealType: MealType;
  status: MealStatus;
  presetNames: string[];
  onVote: (name: string) => void;
  onReset: () => void;
  isVoting: boolean;
  isResetting: boolean;
}

const mealConfig = {
  Breakfast: {
    emoji: '🥐',
    gradient: 'from-white to-pink-50 dark:from-card dark:to-pink-950/20',
  },
  Lunch: {
    emoji: '🍱',
    gradient: 'from-white to-purple-50 dark:from-card dark:to-purple-950/20',
  },
  Dinner: {
    emoji: '🍲',
    gradient: 'from-white to-emerald-50 dark:from-card dark:to-emerald-950/20',
  },
};

export default function MealCard({ 
  mealType, 
  status, 
  presetNames,
  onVote,
  onReset,
  isVoting,
  isResetting
}: MealCardProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [selectedName, setSelectedName] = useState('');
  const [showResetDialog, setShowResetDialog] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const config = mealConfig[mealType];

  const notEatenNames = presetNames.filter(name => !status.eaten.includes(name));
  const filteredNames = notEatenNames.filter(name => 
    name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleVote = () => {
    if (selectedName.trim()) {
      onVote(selectedName.trim());
      setSelectedName('');
      setSearchQuery('');
      setShowDropdown(false);
    }
  };

  const handleSelectName = (name: string) => {
    setSelectedName(name);
    setSearchQuery(name);
    setShowDropdown(false);
  };

  const handleSearchFocus = () => {
    setShowDropdown(true);
  };

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    setSelectedName(value);
    setShowDropdown(true);
  };

  const handleResetConfirm = () => {
    onReset();
    setShowResetDialog(false);
  };

  return (
    <div 
      className={`relative p-6 rounded-2xl shadow-lg transition-all duration-200 bg-gradient-to-br ${config.gradient} hover:-translate-y-1 hover:shadow-xl border border-card-border`}
    >
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="text-base text-muted-foreground font-medium">{mealType}</div>
          <div className="text-5xl mt-2">{config.emoji}</div>
        </div>
        <div className="text-right">
          <div className="text-sm text-muted-foreground">Total Eaten</div>
          <div className="text-3xl font-bold text-primary tabular-nums">{status.eaten_count}</div>
          <div className="text-sm text-muted-foreground mt-1">
            Not Eaten: <span className="tabular-nums font-semibold text-foreground">{status.not_eaten_count}</span>
          </div>
        </div>
      </div>

      <div className="mb-6" ref={dropdownRef}>
        <div className="flex gap-2 mb-2">
          <div className="flex-1 relative">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => handleSearchChange(e.target.value)}
                onFocus={handleSearchFocus}
                placeholder="Search your name..."
                className="pl-10 w-full"
                data-testid={`input-search-${mealType.toLowerCase()}`}
              />
            </div>
            
            {showDropdown && filteredNames.length > 0 && (
              <div className="absolute z-10 w-full mt-1 bg-popover border border-popover-border rounded-lg shadow-lg max-h-60 overflow-auto">
                {filteredNames.map((name, idx) => (
                  <button
                    key={`${name}-${idx}`}
                    type="button"
                    onClick={() => handleSelectName(name)}
                    className="w-full px-4 py-2.5 text-left text-sm hover-elevate text-foreground flex items-center gap-2"
                    data-testid={`option-${mealType.toLowerCase()}-${name}`}
                  >
                    <Circle className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                    <span className="flex-1">{name}</span>
                    <Check className="h-3 w-3 text-green-600 dark:text-green-400 flex-shrink-0 opacity-0 group-hover:opacity-100" />
                  </button>
                ))}
              </div>
            )}
          </div>
          <Button 
            onClick={handleVote}
            disabled={!selectedName.trim() || isVoting}
            variant="default"
            className="px-6"
            data-testid={`button-vote-${mealType.toLowerCase()}`}
          >
            I've eaten
          </Button>
        </div>
        
        <div className="flex items-center justify-between">
          {presetNames.length > 0 && (
            <div className="text-xs text-muted-foreground">
              {notEatenNames.length} girls yet to eat
            </div>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowResetDialog(true)}
            disabled={isResetting || status.eaten_count === 0}
            className="ml-auto"
            data-testid={`button-reset-${mealType.toLowerCase()}`}
          >
            <RotateCcw className="h-3 w-3 mr-1" />
            Reset
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="text-sm">
          <div className="font-semibold text-foreground mb-3 flex items-center gap-2">
            <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
            Who Ate ({status.eaten_count})
          </div>
          <ScrollArea className="h-64 rounded-md border border-border/50 p-3 bg-background/30">
            {status.eaten.length > 0 ? (
              <ul className="space-y-2 pr-2">
                {[...status.eaten].reverse().map((person, idx) => (
                  <li 
                    key={`ate-${person}-${idx}`}
                    className="text-sm text-foreground flex items-center gap-2 py-1"
                    data-testid={`text-person-${mealType.toLowerCase()}-${idx}`}
                  >
                    <Check className="h-3 w-3 text-green-600 dark:text-green-400 flex-shrink-0" />
                    <span>{person}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="text-muted-foreground text-center py-8">No one has eaten yet</div>
            )}
          </ScrollArea>
        </div>

        <div className="text-sm">
          <div className="font-semibold text-foreground mb-3 flex items-center gap-2">
            <X className="h-4 w-4 text-destructive" />
            Not Eaten Yet ({notEatenNames.length})
          </div>
          <ScrollArea className="h-64 rounded-md border border-border/50 p-3 bg-background/30">
            {notEatenNames.length > 0 ? (
              <ul className="space-y-2 pr-2">
                {notEatenNames.map((person, idx) => (
                  <li 
                    key={`not-ate-${person}-${idx}`}
                    className="text-sm text-muted-foreground flex items-center gap-2 py-1"
                    data-testid={`text-not-eaten-${mealType.toLowerCase()}-${idx}`}
                  >
                    <Circle className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                    <span>{person}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="text-green-600 dark:text-green-400 text-center py-8 font-medium">
                Everyone has eaten! 🎉
              </div>
            )}
          </ScrollArea>
        </div>
      </div>

      <AlertDialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reset {mealType} Votes?</AlertDialogTitle>
            <AlertDialogDescription>
              This will clear all votes for {mealType}. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid={`button-cancel-reset-${mealType.toLowerCase()}`}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleResetConfirm}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid={`button-confirm-reset-${mealType.toLowerCase()}`}
            >
              Reset
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

import LiveSummary from '../LiveSummary';

export default function LiveSummaryExample() {
  const mockStatus = {
    Breakfast: { eaten_count: 45, eaten: [], not_eaten_count: 25 },
    Lunch: { eaten_count: 32, eaten: [], not_eaten_count: 38 },
    Dinner: { eaten_count: 18, eaten: [], not_eaten_count: 52 },
    last_reset: new Date().toISOString(),
    expected: 70,
  };

  return (
    <div className="p-6 bg-background">
      <LiveSummary status={mockStatus} />
    </div>
  );
}

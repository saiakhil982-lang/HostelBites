import TutorialModal from '../TutorialModal';

export default function TutorialModalExample() {
  return <TutorialModal onClose={() => console.log('Tutorial closed')} />;
}

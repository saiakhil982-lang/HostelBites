import MealCard from '../MealCard';

export default function MealCardExample() {
  const mockStatus = {
    eaten_count: 5,
    eaten: ['Sarah Johnson', 'Emma Wilson', 'Olivia Brown', 'Ava Davis', 'Mia Rodriguez'],
    not_eaten_count: 5,
  };

  const mockNames = [
    'Sarah Johnson', 'Emma Wilson', 'Olivia Brown', 'Ava Davis', 
    'Isabella Garcia', 'Sophia Martinez', 'Mia Rodriguez', 
    'Charlotte Lopez', 'Amelia Lee', 'Harper Walker'
  ];

  return (
    <div className="p-6 bg-background min-h-screen">
      <div className="max-w-xl mx-auto">
        <MealCard
          mealType="Breakfast"
          status={mockStatus}
          presetNames={mockNames}
          onVote={(name) => console.log('Vote:', name)}
          onReset={() => console.log('Reset clicked')}
          isVoting={false}
          isResetting={false}
        />
      </div>
    </div>
  );
}

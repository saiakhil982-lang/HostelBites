import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import MealCard from "@/components/MealCard";
import LiveSummary from "@/components/LiveSummary";
import TutorialModal from "@/components/TutorialModal";
import confetti from "canvas-confetti";
import { Download, Sparkles } from "lucide-react";
import type { StatusResponse, VoteRequest, VoteResponse, MealType, ResetResponse } from "@shared/schema";

export default function Home() {
  const [showTutorial, setShowTutorial] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (!localStorage.getItem('tutorialSeen')) {
      setShowTutorial(true);
    }
  }, []);

  const closeTutorial = () => {
    setShowTutorial(false);
    localStorage.setItem('tutorialSeen', '1');
  };

  const { data: status, isLoading } = useQuery<StatusResponse>({
    queryKey: ['/api/status'],
    refetchInterval: 5000,
  });

  const { data: presetNames = [] } = useQuery<string[]>({
    queryKey: ['/api/preset-names'],
  });

  const voteMutation = useMutation({
    mutationFn: async (voteData: VoteRequest) => {
      const res = await fetch('/api/vote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(voteData),
        credentials: 'include',
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Vote failed');
      }
      
      return await res.json() as VoteResponse;
    },
    onSuccess: (data) => {
      if (data.success) {
        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.6 },
        });
        queryClient.invalidateQueries({ queryKey: ['/api/status'] });
      } else {
        toast({
          title: "Error",
          description: data.message,
          variant: "destructive",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Could not record your vote. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetMutation = useMutation({
    mutationFn: async (meal: MealType) => {
      const res = await apiRequest('POST', `/api/reset/${meal}`);
      return await res.json() as ResetResponse;
    },
    onSuccess: (data, meal) => {
      if (data.success) {
        toast({
          title: "Reset Successful",
          description: `${meal} votes have been cleared.`,
        });
        queryClient.invalidateQueries({ queryKey: ['/api/status'] });
      }
    },
    onError: () => {
      toast({
        title: "Reset Failed",
        description: "Could not reset votes. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleVote = (meal: MealType) => (name: string) => {
    voteMutation.mutate({ name, meal });
  };

  const handleReset = (meal: MealType) => () => {
    resetMutation.mutate(meal);
  };

  const handleExport = async () => {
    try {
      const response = await fetch('/api/export');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'hostelbites_export.csv';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Export Successful",
        description: "CSV file downloaded successfully.",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Could not export CSV. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDownloadFiles = async () => {
    try {
      const response = await fetch('/api/download-files');
      const files = await response.json();
      
      const dataStr = JSON.stringify(files, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = window.URL.createObjectURL(dataBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'hostelbites_backup.json';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Backup Downloaded",
        description: "All files backed up successfully. You can now update names.json locally.",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Could not download backup files.",
        variant: "destructive",
      });
    }
  };

  if (isLoading || !status) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-50 via-purple-50 to-emerald-50 dark:from-background dark:via-background dark:to-background">
        <div className="text-2xl font-bold text-primary animate-pulse">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6 bg-gradient-to-br from-pink-50 via-purple-50 to-emerald-50 dark:from-background dark:via-background dark:to-background animate-gradient relative overflow-hidden">
      {showTutorial && <TutorialModal onClose={closeTutorial} />}
      
      <div className="absolute top-10 left-10 opacity-20 animate-float">
        <Sparkles className="h-16 w-16 text-pink-500" />
      </div>
      <div className="absolute bottom-20 right-20 opacity-20 animate-float-delayed">
        <Sparkles className="h-12 w-12 text-purple-500" />
      </div>
      
      <div className="max-w-[1600px] mx-auto relative z-10">
        <header className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
          <div className="flex items-center gap-4">
            <div className="text-4xl animate-bounce">💖</div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-emerald-500 bg-clip-text text-transparent animate-gradient">
                HostelBites
              </h1>
              <p className="text-sm text-muted-foreground">
                Search your name and vote when you've eaten — track who's left!
              </p>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <div className="text-sm text-muted-foreground text-right">
              Total Girls: <strong className="text-foreground">{status.expected}</strong>
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={handleExport}
                variant="secondary"
                size="sm"
                data-testid="button-export"
              >
                📊 Export CSV
              </Button>
              <Button 
                onClick={handleDownloadFiles}
                variant="outline"
                size="sm"
                data-testid="button-download-files"
              >
                <Download className="h-3 w-3 mr-1" />
                Backup Files
              </Button>
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          <div className="xl:col-span-3 space-y-6">
            <div className="backdrop-blur-md bg-card/55 rounded-2xl p-6 shadow-lg border border-card-border">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-2">
                <h2 className="text-xl font-semibold text-primary">Vote Your Meal</h2>
                <div className="text-sm text-muted-foreground">
                  Search your name and click "I've eaten" to vote
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-4">
                {(['Breakfast', 'Lunch', 'Dinner'] as const).map((mealType) => (
                  <MealCard
                    key={mealType}
                    mealType={mealType}
                    status={status[mealType]}
                    presetNames={presetNames}
                    onVote={handleVote(mealType)}
                    onReset={handleReset(mealType)}
                    isVoting={voteMutation.isPending}
                    isResetting={resetMutation.isPending}
                  />
                ))}
              </div>

              <div className="text-xs text-muted-foreground">
                💡 Data auto-resets daily at midnight. Use "Backup Files" to save names.json and data.json to your computer.
              </div>
            </div>
          </div>

          <LiveSummary status={status} />
        </div>

        <footer className="mt-6 text-center text-xs text-muted-foreground">
          Made for your hostel — free to use 💕
        </footer>
      </div>
    </div>
  );
}

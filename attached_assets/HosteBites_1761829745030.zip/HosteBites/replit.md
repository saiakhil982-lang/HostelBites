# HostelBites - Meal Tracker

## Overview

HostelBites is a real-time meal attendance tracking system designed for hostel environments. The application allows residents to mark their attendance for Breakfast, Lunch, and Dinner, with live updates showing who has eaten and who hasn't. The system features a dual-column view for each meal, confetti celebrations on vote submission, automatic daily resets at midnight, and CSV export capabilities for attendance records.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18+ with TypeScript using Vite as the build tool

**UI Components**: Built with Radix UI primitives and shadcn/ui component system, following a "New York" style configuration with customized color schemes for light and dark modes

**State Management**: TanStack Query (React Query) for server state with 5-second polling intervals for live updates, local React state for UI interactions

**Design System**: 
- Custom color palette with meal-specific accents (pink for Breakfast, purple for Lunch, mint for Dinner)
- Poppins font family from Google Fonts
- Tailwind CSS with custom theme extensions
- Light and dark mode support with gradient backgrounds
- Warmth and playfulness as core design principles

**Key Features**:
- Real-time status polling every 5 seconds
- Search-based name selection with fuzzy matching
- Confetti animation using canvas-confetti library
- Tutorial modal for first-time users (localStorage-based)
- Two-column layout showing "Who Ate" and "Not Eaten Yet"

### Backend Architecture

**Runtime**: Node.js with Express.js server

**Data Persistence**: File-based JSON storage (data.json) for meal attendance records and preset names (names.json). While Drizzle ORM and PostgreSQL schema are configured, the current implementation uses a memory-based storage adapter that reads/writes to JSON files.

**API Design**: RESTful endpoints:
- `GET /api/status` - Returns current meal status for all three meals
- `POST /api/vote` - Records a person's meal attendance
- `POST /api/reset/:meal` - Resets a specific meal section
- `POST /api/reset-all` - Resets all meals
- `GET /api/preset-names` - Returns the list of all residents
- `GET /api/export-csv` - Exports attendance data as CSV
- `GET /api/backup-files` - Downloads complete backup JSON

**Storage Implementation**: MemStorage class handles:
- Loading and saving JSON files
- Vote validation (prevents duplicate votes per meal)
- Automatic daily reset logic based on last_reset timestamp
- Status calculation with eaten/not-eaten counts

### Data Models

**MealDataStructure**:
```typescript
{
  meals: {
    Breakfast: { eaten: string[] },
    Lunch: { eaten: string[] },
    Dinner: { eaten: string[] }
  },
  last_reset: string (ISO timestamp)
}
```

**StatusResponse**: Includes counts and lists for each meal, plus expected total (70 residents)

**Preset Names**: Array of up to 70 resident names stored in names.json, shared across all meal sections

### External Dependencies

**Third-Party Libraries**:
- `@tanstack/react-query` - Server state management and caching
- `canvas-confetti` - Celebration animations on vote submission
- `wouter` - Lightweight client-side routing
- `drizzle-orm` and `@neondatabase/serverless` - Configured for PostgreSQL (not actively used, files-based storage is current implementation)
- `react-hook-form` with `@hookform/resolvers` - Form handling
- `zod` - Runtime validation schemas
- `date-fns` - Date manipulation
- Radix UI components - Accessible UI primitives (@radix-ui/react-*)

**Development Tools**:
- Vite with React plugin and runtime error overlay
- TypeScript with strict mode enabled
- Tailwind CSS with PostCSS
- ESBuild for server bundling

**Fonts**: Google Fonts (Poppins family with weights 300, 400, 600, 700)

**Database** (configured but not in use): PostgreSQL via Neon with Drizzle ORM schema defined in shared/schema.ts. The application currently operates on file-based storage but can be migrated to PostgreSQL by implementing a database-backed storage adapter.

**Session Management**: `connect-pg-simple` configured for PostgreSQL session storage

**Environment Variables**:
- `DATABASE_URL` - PostgreSQL connection string (required for Drizzle config)
- `EXPECTED_COUNT` - Number of expected residents (defaults to 70)
- `NODE_ENV` - Environment mode (development/production)